import logging
import asyncio
import aiohttp
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatMember
from telegram.ext import (
    Application, MessageHandler, CommandHandler,
    CallbackQueryHandler, ContextTypes, filters
)

# ─── CONFIG ──────────────────────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = "8943230974:AAFbPnSuLFzUirp0W-zGJk_m0tSJu1DlKw8"
OPENROUTER_API_KEY = "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"
ADMIN_ID           = 8690101844
CHANNEL_USERNAME   = "@mdsiddik90"
CHANNEL_CHAT_ID    = -1003953554451

# Store all user chat IDs (for admin broadcast)
user_ids: set[int] = set()

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)


# ─── HELPER: CHECK CHANNEL MEMBERSHIP ────────────────────────────────────────
async def is_member(bot, user_id: int) -> bool:
    try:
        member = await bot.get_chat_member(chat_id=CHANNEL_CHAT_ID, user_id=user_id)
        return member.status in (
            ChatMember.MEMBER,
            ChatMember.ADMINISTRATOR,
            ChatMember.OWNER,
        )
    except Exception as e:
        logger.warning(f"Membership check failed for {user_id}: {e}")
        return False


# ─── HELPER: ASK AI VIA OPENROUTER ───────────────────────────────────────────
async def ask_ai(user_message: str, history: list) -> str:
    messages = history + [{"role": "user", "content": user_message}]
    url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://t.me/mdsiddik90",
        "X-Title": "Telegram AI Bot",
    }
    payload = {
        "model": "openai/gpt-3.5-turbo",
        "messages": messages,
        "max_tokens": 800,
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=payload) as resp:
            data = await resp.json()
            return data["choices"][0]["message"]["content"].strip()


# ─── NOT-A-MEMBER REPLY ───────────────────────────────────────────────────────
NOT_JOINED_TEXT = (
    "🔒 *এই বটটি ব্যবহার করতে আমাদের চ্যানেলে জয়েন করুন!*\n\n"
    "👇 নিচের বাটনে ক্লিক করে চ্যানেলে জয়েন করুন, তারপর ✅ *Joined* বাটন চাপুন।"
)

def not_joined_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 চ্যানেলে জয়েন করুন", url=f"https://t.me/mdsiddik90")],
        [InlineKeyboardButton("✅ জয়েন করেছি", callback_data="check_join")],
    ])


# ─── CONVERSATION HISTORY (in-memory) ────────────────────────────────────────
chat_histories: dict[int, list] = {}


# ─── HANDLERS ────────────────────────────────────────────────────────────────
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    chat_id = update.effective_chat.id

    # Track user
    user_ids.add(chat_id)

    # Check channel membership
    if not await is_member(context.bot, user.id):
        await update.message.reply_text(
            NOT_JOINED_TEXT,
            parse_mode="Markdown",
            reply_markup=not_joined_keyboard()
        )
        return

    # Member — process with AI
    user_text = update.message.text
    history = chat_histories.get(chat_id, [])

    await context.bot.send_chat_action(chat_id=chat_id, action="typing")
    try:
        reply = await ask_ai(user_text, history)
    except Exception as e:
        logger.error(f"AI error: {e}")
        reply = "⚠️ দুঃখিত, এই মুহূর্তে AI উত্তর দিতে পারছে না। একটু পরে চেষ্টা করুন।"

    # Update history (keep last 10 turns)
    history.append({"role": "user", "content": user_text})
    history.append({"role": "assistant", "content": reply})
    chat_histories[chat_id] = history[-20:]

    await update.message.reply_text(reply)


async def check_join_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user

    if await is_member(context.bot, user.id):
        await query.edit_message_text(
            "✅ *চ্যানেলে জয়েন করার জন্য ধন্যবাদ!*\n\n"
            "এখন আপনি বটের সাথে কথা বলতে পারবেন। যেকোনো প্রশ্ন করুন! 🤖",
            parse_mode="Markdown"
        )
    else:
        await query.answer("❌ আপনি এখনও চ্যানেলে জয়েন করেননি!", show_alert=True)


# ─── ADMIN BROADCAST ──────────────────────────────────────────────────────────
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("⛔ এই কমান্ড শুধু অ্যাডমিনের জন্য।")
        return

    if not context.args:
        await update.message.reply_text(
            "📢 ব্যবহার: `/broadcast আপনার মেসেজ এখানে লিখুন`",
            parse_mode="Markdown"
        )
        return

    message = " ".join(context.args)
    success, failed = 0, 0

    for uid in list(user_ids):
        try:
            await context.bot.send_message(chat_id=uid, text=f"📣 *অ্যাডমিন বার্তা:*\n\n{message}", parse_mode="Markdown")
            success += 1
        except Exception:
            failed += 1

    await update.message.reply_text(
        f"✅ ব্রডকাস্ট সম্পন্ন!\n✔️ সফল: {success}\n❌ ব্যর্থ: {failed}"
    )


# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()

    # Admin broadcast command
    app.add_handler(CommandHandler("broadcast", broadcast))

    # Check join callback
    app.add_handler(CallbackQueryHandler(check_join_callback, pattern="^check_join$"))

    # All text messages
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("🤖 Bot started!")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
